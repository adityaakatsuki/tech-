# 🔧 Company Technology Usage Analysis

A comprehensive Streamlit-based dashboard for analyzing and visualizing technology adoption, usage patterns, and software inventory across your organization.

## 📋 Features

- **Dashboard Overview** - High-level metrics and key insights
- **Technology Catalog** - Browse and search technologies with adoption rates
- **Department Analytics** - Analyze tech usage by department and cross-department comparisons
- **Reports & Exports** - Generate reports and export data in multiple formats (CSV, JSON, Excel)
- **Interactive Visualizations** - Plotly-based charts and graphs for data exploration
- **Data Filtering** - Search, filter, and segment data by multiple criteria

## 📁 Project Structure

```
company_tech_analysis/
├── app.py                           # Main Streamlit application entry point
├── pages/                           # Multi-page app components
│   ├── 1_Technologies.py           # Technology catalog and search
│   ├── 2_Departments.py            # Department analytics
│   └── 3_Reports.py                # Reports generation and data export
├── utils/                           # Utility modules
│   ├── __init__.py                 # Package initializer
│   ├── data_loader.py              # Data loading from CSV, JSON, database
│   └── data_processor.py           # Data transformation and aggregation
├── data/                            # Data storage
│   └── technologies.csv            # Sample technology dataset
├── assets/                          # Static assets (images, icons, etc.)
├── .streamlit/                      # Streamlit configuration
│   └── config.toml                 # Theme and app settings
├── .gitignore                       # Git ignore rules
├── requirements.txt                 # Python dependencies
└── README.md                        # This file

```

## 🚀 Quick Start

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)

### Installation

1. **Clone or download the repository**
   ```bash
   cd company_tech_analysis
   ```

2. **Create a virtual environment** (recommended)
   ```bash
   python -m venv venv
   # Windows
   venv\Scripts\activate
   # macOS/Linux
   source venv/bin/activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Run the application**
   ```bash
   streamlit run app.py
   ```

The app will open in your default browser at `http://localhost:8501`

## 📊 File & Folder Descriptions

### Core Application Files

| File | Purpose |
|------|---------|
| `app.py` | Main Streamlit application with Dashboard, Technologies, Departments, and Reports pages. Contains navigation menu and data loading logic. |

### Pages (Multi-Page Components)

| File | Purpose |
|------|---------|
| `pages/1_Technologies.py` | Displays complete technology catalog with search, filtering, and adoption rate visualizations. Users can explore individual technologies and their usage patterns. |
| `pages/2_Departments.py` | Shows department-level analytics including technology breakdown, adoption metrics, and cross-department comparisons. |
| `pages/3_Reports.py` | Generates executive summaries, detailed analysis reports, technology inventory, and enables data export in CSV/JSON formats. |

### Utility Modules

| File | Purpose |
|------|---------|
| `utils/data_loader.py` | Handles data loading from multiple sources (CSV, JSON, database). Includes function to load sample data for testing. |
| `utils/data_processor.py` | Data cleaning, transformation, and aggregation functions. Processes raw data for visualization and analysis. |

### Data Directory

| File | Purpose |
|------|---------|
| `data/technologies.csv` | Sample technology dataset with columns: technologies, department, project_name, adoption_rate, status. Replace with your actual data. |

### Configuration

| File | Purpose |
|------|---------|
| `.streamlit/config.toml` | Streamlit theme configuration (colors, fonts, logging levels, server settings). Customize the look and feel of the application. |

### Development Files

| File | Purpose |
|------|---------|
| `requirements.txt` | Lists all Python package dependencies needed to run the application. |
| `.gitignore` | Specifies files and directories to exclude from version control (cache, env, secrets). |

### Assets Directory

| Directory | Purpose |
|-----------|---------|
| `assets/` | Placeholder directory for static files like logos, custom images, and icons used in the application. |

## 📈 Data Schema

The application expects technology data with the following columns:

```
technologies  : Name of the technology (e.g., Python, React, AWS)
department    : Department using the technology (e.g., Engineering, Frontend)
project_name  : Associated project (e.g., Project A)
adoption_rate : Adoption percentage (0-100)
status        : Status of technology (Active, Planned, Deprecated)
```

## 🔧 Configuration

### Customize Theme
Edit `.streamlit/config.toml` to change:
- Color scheme (primary, background, secondary colors)
- Font and layout
- Server settings

### Load Your Data
Replace `data/technologies.csv` with your actual data, or modify `utils/data_loader.py` to connect to:
- Database (PostgreSQL, MySQL, etc.)
- API endpoints
- Other data sources

## 📦 Dependencies

- **streamlit**: Web app framework
- **pandas**: Data manipulation and analysis
- **plotly**: Interactive visualizations
- **numpy**: Numerical computations
- **sqlalchemy**: Database ORM (optional)
- **openpyxl**: Excel file handling (optional)

## 🎯 Usage Examples

### Running the App
```bash
streamlit run app.py
```

### Using the Dashboard
1. **Dashboard**: View overall metrics and technology distribution
2. **Technologies**: Search for specific technologies and see adoption rates
3. **Departments**: Analyze which departments use which technologies
4. **Reports**: Generate summaries and export data

## 🛠️ Extending the Application

### Add New Data Sources
Modify `utils/data_loader.py` to add support for databases or APIs.

### Add New Pages
Create new files in the `pages/` directory following Streamlit's multi-page app convention (e.g., `4_Advanced_Analytics.py`).

### Add Visualizations
Import additional Plotly or Matplotlib charts in page files and use the processed data from `utils/data_processor.py`.

## 🐛 Troubleshooting

**Port Already in Use**
```bash
streamlit run app.py --server.port 8502
```

**Data Not Loading**
- Verify `data/technologies.csv` exists
- Check file format matches expected schema
- Review `utils/data_loader.py` for correct file path

**Dependencies Missing**
```bash
pip install -r requirements.txt
```

## 📝 License

This project is provided as-is for internal use.

## 👥 Contributing

To improve this application:
1. Add new analytics features
2. Optimize data loading and processing
3. Enhance visualizations
4. Add database connectivity

## 📞 Support

For questions or issues, refer to:
- [Streamlit Documentation](https://docs.streamlit.io/)
- [Plotly Documentation](https://plotly.com/python/)
- [Pandas Documentation](https://pandas.pydata.org/)
