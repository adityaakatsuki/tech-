"""
Data Loader Module
Handles loading technology data from various sources (CSV, JSON, database, API)

Added SQLite database integration: use source='database' to load from SQLite DB located in company_tech_analysis/data/technologies.db.
Utilities provided to import CSV into DB and save DataFrames into the DB.
"""

import pandas as pd
import os
from .db import get_db_path, fetch_all, import_csv_to_db, insert_dataframe


def load_technology_data(source='csv'):
    """
    Load technology data from specified source.
    
    Args:
        source (str): Data source type ('csv', 'json', 'database')
    
    Returns:
        pd.DataFrame: Technology data
    """
    data_dir = os.path.join(os.path.dirname(__file__), '..', 'data')
    data_dir = os.path.abspath(data_dir)

    if source == 'csv':
        csv_path = os.path.join(data_dir, 'technologies.csv')
        if os.path.exists(csv_path):
            return pd.read_csv(csv_path)
        else:
            return pd.DataFrame()
    
    elif source == 'json':
        json_path = os.path.join(data_dir, 'technologies.json')
        if os.path.exists(json_path):
            return pd.read_json(json_path)
        else:
            return pd.DataFrame()
    
    elif source == 'database':
        db_path = get_db_path(base_dir=data_dir)
        # If DB exists and has data, fetch it
        if os.path.exists(db_path):
            try:
                df = fetch_all(db_path)
                if df is not None and not df.empty:
                    return df
            except Exception:
                # fall through to attempt CSV import
                pass

        # If DB is missing or empty, try to import CSV into DB if CSV exists
        csv_path = os.path.join(data_dir, 'technologies.csv')
        if os.path.exists(csv_path):
            try:
                df = import_csv_to_db(csv_path, db_path=db_path)
                return df
            except Exception:
                # fallback to reading CSV directly
                return pd.read_csv(csv_path)

        # nothing found
        return pd.DataFrame()
    
    return pd.DataFrame()


def save_technology_data_to_db(df: pd.DataFrame, db_path: str = None) -> None:
    """Save a DataFrame of technology records into the SQLite DB.

    This will create the DB/table if needed and insert rows.
    """
    if db_path is None:
        db_path = get_db_path()
    insert_dataframe(df, db_path=db_path)


def load_sample_data():
    """
    Load sample/mock data for development and testing.
    
    Returns:
        pd.DataFrame: Sample technology data
    """
    sample_data = {
        'technologies': ['Python', 'JavaScript', 'React', 'AWS', 'Docker', 'PostgreSQL', 'Python', 'React', 'AWS'],
        'department': ['Engineering', 'Frontend', 'Frontend', 'DevOps', 'DevOps', 'Database', 'Data Science', 'Frontend', 'Engineering'],
        'project_name': ['Project A', 'Project B', 'Project C', 'Project A', 'Project B', 'Project C', 'Project D', 'Project E', 'Project F'],
        'adoption_rate': [85, 90, 88, 75, 80, 70, 95, 92, 78],
        'status': ['Active', 'Active', 'Active', 'Active', 'Planned', 'Active', 'Active', 'Active', 'Deprecated']
    }
    return pd.DataFrame(sample_data)
