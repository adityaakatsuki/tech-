"""
Simple keyword-based technology detector.

Functions:
- detect_from_text(text): returns dict with technologies, vendors, categories, and matches (with spans)
- detect_technologies(text), detect_vendors(text), detect_categories(text)
- add_keyword(kind, keyword, category=None): extend lists at runtime

Matching is case-insensitive and uses word-boundary-aware regex. Longer keywords are matched first to avoid partial matches.
"""
from typing import List, Dict, Tuple
import re

# Category -> list of keywords
CATEGORIES = {
    'Programming Language': [
        'Python', 'Java', 'C#', r'C\+\+', 'Go', 'Rust', 'Kotlin', 'PHP', 'Ruby', 'Swift', 'Objective-C', 'R', 'Scala'
    ],
    'Frontend Framework': [
        'React', 'Vue.js', 'Vue', 'Angular', 'Svelte', 'Next.js', 'Next', 'Nuxt', 'Gatsby', 'Ember', 'SvelteKit'
    ],
    'Backend Framework': [
        'Django', 'Flask', 'FastAPI', 'Express', 'Spring Boot', 'ASP.NET', 'Laravel', 'Node.js', 'Node'
    ],
    'Database': [
        'PostgreSQL', 'MySQL', 'MongoDB', 'Redis', 'SQLite', 'Oracle', 'Cassandra', 'MariaDB', 'DynamoDB', 'Elasticsearch'
    ],
    'Cloud': [
        'AWS', 'Amazon Web Services', 'Azure', 'Google Cloud', 'GCP', 'DigitalOcean', 'Heroku', 'Vercel'
    ],
    'DevOps/Infra': [
        'Docker', 'Kubernetes', 'Terraform', 'Ansible', 'Jenkins', 'GitHub Actions', 'GitLab CI', 'CircleCI', 'ArgoCD'
    ],
    'Data & Analytics': [
        'TensorFlow', 'PyTorch', 'Spark', 'Apache Spark', 'Hadoop', 'Kafka', 'Snowflake', 'Tableau', 'Power BI'
    ],
    'Monitoring/Logging': [
        'Prometheus', 'Grafana', 'Datadog', 'New Relic', 'Splunk', 'ELK', 'Elastic', 'CloudWatch', 'Sentry'
    ],
    'Testing': [
        'Jest', 'Pytest', 'Selenium', 'JUnit', 'Cypress', 'Playwright'
    ],
    'Web Platform/CDN': [
        'WordPress', 'Shopify', 'Cloudflare', 'Fastly', 'Akamai', 'jQuery', 'Webpack', 'Bootstrap',
        'Tailwind CSS', 'Google Analytics', 'Google Tag Manager', 'Squarespace', 'Wix', 'Contentful',
        'Algolia', 'Segment', 'Stripe'
    ]
}

# Vendors / providers
VENDORS = [
    'Amazon', 'Amazon Web Services', 'AWS', 'Microsoft', 'Azure', 'Google', 'Google Cloud', 'GCP',
    'Datadog', 'Splunk', 'Elastic', 'HashiCorp', 'Red Hat', 'IBM', 'Oracle', 'MongoDB Inc', 'MongoDB',
    'Cloudflare', 'Fastly', 'Akamai', 'Automattic', 'Shopify', 'Segment', 'Stripe', 'Algolia',
    'Contentful', 'Squarespace', 'Wix'
]

# Build a reverse map: keyword -> category
KEYWORD_TO_CATEGORY: Dict[str, str] = {}
for cat, kws in CATEGORIES.items():
    for kw in kws:
        KEYWORD_TO_CATEGORY[kw] = cat

# Flatten lists of keywords for matching
TECH_KEYWORDS = sorted(KEYWORD_TO_CATEGORY.keys(), key=lambda s: -len(s))
VENDOR_KEYWORDS = sorted(VENDORS, key=lambda s: -len(s))

# Case-insensitive lookup to canonical casing, since matching is case-insensitive
# but text can contain a keyword in any case (e.g. "docker" in a URL slug)
_TECH_CANONICAL = {kw.lower(): kw for kw in KEYWORD_TO_CATEGORY}
_VENDOR_CANONICAL = {kw.lower(): kw for kw in VENDOR_KEYWORDS}

# Compile regex for performance
def _build_pattern(keywords: List[str]) -> re.Pattern:
    # Escape keywords, but keep common punctuation like '.' and '+' which are escaped by re.escape
    escaped = [re.escape(k) for k in keywords]
    # Use lookarounds to avoid matching inside words
    pattern = r'(?<!\w)(' + '|'.join(escaped) + r')(?!\w)'
    return re.compile(pattern, flags=re.IGNORECASE)

_TECH_PATTERN = _build_pattern(TECH_KEYWORDS) if TECH_KEYWORDS else None
_VENDOR_PATTERN = _build_pattern(VENDOR_KEYWORDS) if VENDOR_KEYWORDS else None


def _find_matches(pattern: re.Pattern, text: str) -> List[Tuple[str, int, int]]:
    if pattern is None:
        return []
    matches = []
    for m in pattern.finditer(text):
        matches.append((m.group(0), m.start(), m.end()))
    return matches


def detect_technologies(text: str) -> List[str]:
    """Return unique technology keywords found in text."""
    matches = _find_matches(_TECH_PATTERN, text)
    # Normalize matched text to canonical keyword (by matching ignoring case)
    found = set()
    for val, s, e in matches:
        # Find canonical by checking KEYWORD_TO_CATEGORY keys case-insensitively
        for kw in KEYWORD_TO_CATEGORY.keys():
            if val.lower() == kw.lower():
                found.add(kw)
                break
        else:
            found.add(val)
    return sorted(found)


def detect_vendors(text: str) -> List[str]:
    """Return unique vendor keywords found in text."""
    matches = _find_matches(_VENDOR_PATTERN, text)
    found = set(m[0] for m in matches)
    # Normalize common variants (e.g., AWS -> Amazon Web Services) not enforced here
    return sorted(found)


def detect_categories(text: str) -> List[str]:
    """Return set of categories inferred from technology matches."""
    techs = detect_technologies(text)
    cats = set()
    for t in techs:
        cat = KEYWORD_TO_CATEGORY.get(t)
        if cat:
            cats.add(cat)
    return sorted(cats)


def detect_from_text(text: str) -> Dict[str, object]:
    """Return a full detection result.

    Result example:
    {
      'technologies': [...],
      'vendors': [...],
      'categories': [...],
      'matches': [
         {'term': 'React', 'kind': 'technology', 'span': (10,15)},
         ...
      ]
    }
    """
    tech_matches = _find_matches(_TECH_PATTERN, text)
    vendor_matches = _find_matches(_VENDOR_PATTERN, text)

    matches = []
    for val, s, e in tech_matches:
        canonical = _TECH_CANONICAL.get(val.lower(), val)
        matches.append({'term': canonical, 'kind': 'technology', 'span': (s, e), 'category': KEYWORD_TO_CATEGORY.get(canonical, None)})
    for val, s, e in vendor_matches:
        canonical = _VENDOR_CANONICAL.get(val.lower(), val)
        matches.append({'term': canonical, 'kind': 'vendor', 'span': (s, e)})

    # Unique lists
    technologies = sorted({m['term'] for m in matches if m['kind'] == 'technology'})
    vendors = sorted({m['term'] for m in matches if m['kind'] == 'vendor'})
    categories = sorted({m['category'] for m in matches if m.get('category')})

    return {
        'technologies': technologies,
        'vendors': vendors,
        'categories': categories,
        'matches': matches
    }


def add_keyword(kind: str, keyword: str, category: str = None) -> None:
    """Add a keyword at runtime. kind in ('technology','vendor','category').

    If kind == 'technology' provide category.
    """
    global _TECH_PATTERN, _VENDOR_PATTERN
    if kind == 'technology':
        if keyword not in KEYWORD_TO_CATEGORY:
            KEYWORD_TO_CATEGORY[keyword] = category or 'Uncategorized'
            TECH_KEYWORDS.insert(0, keyword)  # prefer this keyword when matching
            _TECH_PATTERN = _build_pattern(TECH_KEYWORDS)
    elif kind == 'vendor':
        if keyword not in VENDOR_KEYWORDS:
            VENDOR_KEYWORDS.insert(0, keyword)
            _VENDOR_PATTERN = _build_pattern(VENDOR_KEYWORDS)
    elif kind == 'category':
        if category and keyword:
            CATEGORIES.setdefault(category, []).append(keyword)
            KEYWORD_TO_CATEGORY[keyword] = category
            TECH_KEYWORDS.insert(0, keyword)
            _TECH_PATTERN = _build_pattern(TECH_KEYWORDS)
    else:
        raise ValueError("kind must be one of 'technology','vendor','category'")
