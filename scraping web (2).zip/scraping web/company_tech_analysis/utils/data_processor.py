"""
Data Processor Module
Handles data cleaning, transformation, and aggregation for analysis
"""

import pandas as pd
import numpy as np

def process_tech_data(data):
    """
    Process and clean technology data.
    
    Args:
        data (pd.DataFrame): Raw technology data
    
    Returns:
        pd.DataFrame: Processed technology data
    """
    if data.empty:
        return data
    
    # Clean column names
    data.columns = data.columns.str.lower().str.strip()
    
    # Handle missing values
    data = data.fillna('Unknown')
    
    # Convert adoption_rate to numeric
    if 'adoption_rate' in data.columns:
        data['adoption_rate'] = pd.to_numeric(data['adoption_rate'], errors='coerce')
    
    return data

def aggregate_by_department(data):
    """
    Aggregate technology usage by department.
    
    Args:
        data (pd.DataFrame): Processed technology data
    
    Returns:
        pd.DataFrame: Department-level aggregation
    """
    if data.empty:
        return data
    
    return data.groupby('department').agg({
        'technologies': 'count',
        'adoption_rate': 'mean'
    }).rename(columns={'technologies': 'tech_count'}).reset_index()

def get_technology_summary(data):
    """
    Generate technology adoption summary statistics.
    
    Args:
        data (pd.DataFrame): Processed technology data
    
    Returns:
        dict: Summary statistics
    """
    if data.empty:
        return {}
    
    return {
        'total_technologies': data['technologies'].nunique(),
        'avg_adoption_rate': data['adoption_rate'].mean(),
        'max_adoption': data['adoption_rate'].max(),
        'min_adoption': data['adoption_rate'].min(),
        'total_projects': len(data)
    }

def filter_active_technologies(data):
    """
    Filter for only active technologies.
    
    Args:
        data (pd.DataFrame): Processed technology data
    
    Returns:
        pd.DataFrame: Active technologies only
    """
    if data.empty:
        return data
    
    if 'status' in data.columns:
        return data[data['status'] == 'Active']
    return data
