"""
SQLite DB helper for storing and retrieving company technology records.
"""
import sqlite3
import os
import pandas as pd
from typing import Optional

DEFAULT_TABLE = "technologies"

CREATE_TABLE_SQL = f"""
CREATE TABLE IF NOT EXISTS {DEFAULT_TABLE} (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    technologies TEXT,
    department TEXT,
    project_name TEXT,
    adoption_rate INTEGER,
    status TEXT,
    team_size INTEGER,
    cost_monthly INTEGER,
    license_type TEXT,
    years_in_use INTEGER,
    last_reviewed TEXT,
    priority TEXT,
    migration_target TEXT
);
"""


def get_db_path(base_dir: Optional[str] = None) -> str:
    """Return path to DB file inside data directory (creates dir if needed)."""
    if base_dir is None:
        base_dir = os.path.join(os.path.dirname(__file__), '..', 'data')
    db_dir = os.path.abspath(base_dir)
    if not os.path.exists(db_dir):
        os.makedirs(db_dir, exist_ok=True)
    return os.path.join(db_dir, 'technologies.db')


def init_db(db_path: Optional[str] = None) -> None:
    """Initialize the SQLite database and ensure the table exists."""
    if db_path is None:
        db_path = get_db_path()
    conn = sqlite3.connect(db_path)
    try:
        cur = conn.cursor()
        cur.executescript(CREATE_TABLE_SQL)
        conn.commit()
    finally:
        conn.close()


def insert_dataframe(df: pd.DataFrame, db_path: Optional[str] = None) -> None:
    """Insert a DataFrame into the technologies table. Columns are mapped by name.

    Non-matching columns are ignored; missing columns are inserted as NULL.
    """
    if db_path is None:
        db_path = get_db_path()

    init_db(db_path)

    cols = [
        'technologies', 'department', 'project_name', 'adoption_rate', 'status',
        'team_size', 'cost_monthly', 'license_type', 'years_in_use', 'last_reviewed',
        'priority', 'migration_target'
    ]

    records = []
    for _, row in df.iterrows():
        values = [None if (col not in df.columns) else row[col] for col in cols]
        records.append(values)

    placeholders = ','.join('?' for _ in cols)
    sql = f"INSERT INTO {DEFAULT_TABLE} ({','.join(cols)}) VALUES ({placeholders})"

    conn = sqlite3.connect(db_path)
    try:
        cur = conn.cursor()
        cur.executemany(sql, records)
        conn.commit()
    finally:
        conn.close()


def fetch_all(db_path: Optional[str] = None) -> pd.DataFrame:
    """Fetch all records from the technologies table as a DataFrame."""
    if db_path is None:
        db_path = get_db_path()

    if not os.path.exists(db_path):
        # Return empty DataFrame with expected columns
        cols = [
            'technologies', 'department', 'project_name', 'adoption_rate', 'status',
            'team_size', 'cost_monthly', 'license_type', 'years_in_use', 'last_reviewed',
            'priority', 'migration_target'
        ]
        return pd.DataFrame(columns=cols)

    conn = sqlite3.connect(db_path)
    try:
        df = pd.read_sql_query(f"SELECT technologies, department, project_name, adoption_rate, status, team_size, cost_monthly, license_type, years_in_use, last_reviewed, priority, migration_target FROM {DEFAULT_TABLE}", conn)
    finally:
        conn.close()
    return df


def import_csv_to_db(csv_path: str, db_path: Optional[str] = None) -> pd.DataFrame:
    """Load CSV into DataFrame and insert into DB. Returns the dataframe loaded from CSV.

    Attempts a forgiving read if the CSV includes comment lines or blank lines.
    """
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"CSV file not found: {csv_path}")

    try:
        df = pd.read_csv(csv_path)
    except pd.errors.ParserError:
        # Try skipping comment lines (lines starting with '#') and blank lines
        df = pd.read_csv(csv_path, comment='#', skip_blank_lines=True)

    # Basic cleanup: strip whitespace from column names
    df.columns = [c.strip() for c in df.columns]

    insert_dataframe(df, db_path=db_path)
    return df
