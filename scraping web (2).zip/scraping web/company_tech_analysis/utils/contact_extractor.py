"""
Client/company contact detail extractor.

Pulls best-effort identifying details from a scraped page: company name,
email addresses, phone numbers, and postal address. These live in
different places than tech fingerprints (page title, meta tags,
mailto:/tel: links, schema.org JSON-LD) so this stays a separate module
from tech_detector.
"""
import json
import re
from typing import Dict, List, Optional

from bs4 import BeautifulSoup

EMAIL_RE = re.compile(r'[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+')
# US/CA-style phone numbers with explicit separators, to avoid grabbing
# arbitrary long digit runs (ids, dates) out of page text.
PHONE_RE = re.compile(r'(?<!\d)(?:\+?\d{1,3}[\s.-]?)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}(?!\d)')

# Domains that show up in scraped text but aren't real contact emails
EMAIL_DOMAIN_BLOCKLIST = {'example.com', 'sentry.io', 'w3.org', 'schema.org'}

# Fallback patterns for finding a postal address directly in page text, for
# sites that don't mark it up with schema.org JSON-LD or an <address> tag
# (most don't - it's usually just plain text in a footer).
_COUNTRY_ALT = r'(?:USA|U\.S\.A\.|US|United States(?:\s+of\s+America)?|United Kingdom|UK|Canada)'
STREET_ADDRESS_RE = re.compile(
    r'\d{1,6}\s+[A-Za-z0-9\'#\s]{3,60}?,\s*'    # street number + name
    r'[A-Za-z\s]{2,40},\s*'                      # city
    r'[A-Z]{2}\s*\d{5}(?:-\d{4})?'               # state + zip
    rf'(?:,\s*{_COUNTRY_ALT})?'                  # optional country, from a known whitelist
)
LOCATION_PHRASE_RE = re.compile(
    r'(?:headquartered in|based in|located at|located in)\s+'
    r'([A-Z][A-Za-z.\'\s]{2,60}?)(?:[.,;]|\s+and\b|\s+with\b|$)'
)


def _leading_segment(text: str) -> str:
    # Titles/og:title are often "Company Name | Tagline" or "Company - Tagline"
    for sep in [" | ", " - ", " — ", ": "]:
        if sep in text:
            return text.split(sep)[0].strip()
    return text


def _extract_company_name(soup: BeautifulSoup) -> Optional[str]:
    og_site = soup.find("meta", attrs={"property": "og:site_name"})
    if og_site and og_site.get("content"):
        return og_site["content"].strip()

    og_title = soup.find("meta", attrs={"property": "og:title"})
    if og_title and og_title.get("content"):
        return _leading_segment(og_title["content"].strip())

    if soup.title and soup.title.string:
        return _leading_segment(soup.title.string.strip())
    return None


def _extract_emails(soup: BeautifulSoup, visible_text: str) -> List[str]:
    found = set()
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if href.lower().startswith("mailto:"):
            addr = href[7:].split("?")[0].strip()
            if addr:
                found.add(addr)
    found.update(EMAIL_RE.findall(visible_text))
    return sorted(e for e in found if e.split("@")[-1].lower() not in EMAIL_DOMAIN_BLOCKLIST)


def _extract_phones(soup: BeautifulSoup, visible_text: str) -> List[str]:
    found = set()
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if href.lower().startswith("tel:"):
            num = href[4:].strip()
            if num:
                found.add(num)
    for m in PHONE_RE.finditer(visible_text):
        found.add(m.group(0).strip())
    return sorted(found)[:5]


def _extract_address(soup: BeautifulSoup, visible_text: str) -> Optional[str]:
    for script in soup.find_all("script", attrs={"type": "application/ld+json"}):
        try:
            data = json.loads(script.string or "")
        except (json.JSONDecodeError, TypeError):
            continue
        candidates = data if isinstance(data, list) else [data]
        for item in candidates:
            if not isinstance(item, dict):
                continue
            addr = item.get("address")
            if isinstance(addr, dict):
                parts = [
                    addr.get("streetAddress"),
                    addr.get("addressLocality"),
                    addr.get("addressRegion"),
                    addr.get("postalCode"),
                    addr.get("addressCountry"),
                ]
                joined = ", ".join(p for p in parts if p)
                if joined:
                    return joined

    address_tag = soup.find("address")
    if address_tag:
        text = address_tag.get_text(separator=", ", strip=True)
        if text:
            return text

    # Most sites don't mark up their address at all - it's just plain text,
    # usually in the footer. Fall back to scanning the visible page text.
    street_match = STREET_ADDRESS_RE.search(visible_text)
    if street_match:
        return street_match.group(0).strip()

    location_match = LOCATION_PHRASE_RE.search(visible_text)
    if location_match:
        return location_match.group(1).strip()

    return None


def extract_contact_details(html: str, visible_text: str) -> Dict[str, object]:
    """Best-effort extraction of client/company contact details.

    Returns a dict with company_name (str|None), emails (list[str]),
    phones (list[str]), and address (str|None).
    """
    soup = BeautifulSoup(html, "html.parser")
    return {
        "company_name": _extract_company_name(soup),
        "emails": _extract_emails(soup, visible_text),
        "phones": _extract_phones(soup, visible_text),
        "address": _extract_address(soup, visible_text),
    }
