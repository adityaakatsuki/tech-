"""
Web scraping module.

Fetches a public webpage and passes its text plus technical fingerprints
(HTTP headers, meta generator tag, script/link URLs - where real tech
signals actually live, since marketing copy rarely names a tech stack)
to the technology detection module (tech_detector).
"""
import requests
from bs4 import BeautifulSoup
from .tech_detector import detect_from_text
from .contact_extractor import extract_contact_details

HEADERS = {"User-Agent": "Mozilla/5.0 (basic-scrape-test/1.0)"}


def fetch_page_text(url: str, timeout: int = 10) -> str:
    """Fetch a URL and return its visible page text (scripts/styles stripped)."""
    resp = requests.get(url, headers=HEADERS, timeout=timeout)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")
    for tag in soup(["script", "style"]):
        tag.decompose()
    return soup.get_text(separator=" ", strip=True)


def fetch_page_signals(url: str, timeout: int = 10) -> tuple:
    """Fetch a URL and return (visible_text, combined_signal_text, raw_html).

    combined_signal_text also includes HTTP response headers, the meta
    generator tag, and script/link URLs, which is where real technology
    fingerprints (CDNs, frameworks, platforms) actually show up. raw_html
    is returned too since contact-detail extraction needs tags (mailto:
    links, JSON-LD) that get stripped out of visible_text.
    """
    resp = requests.get(url, headers=HEADERS, timeout=timeout)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")

    header_signals = " ".join(f"{k}:{v}" for k, v in resp.headers.items())

    generator_tag = soup.find("meta", attrs={"name": "generator"})
    generator_signal = generator_tag.get("content", "") if generator_tag else ""

    resource_urls = [
        tag.get("src") or tag.get("href")
        for tag in soup.find_all(["script", "link"])
        if tag.get("src") or tag.get("href")
    ]
    resource_signals = " ".join(resource_urls)

    for tag in soup(["script", "style"]):
        tag.decompose()
    visible_text = soup.get_text(separator=" ", strip=True)

    combined = " ".join([visible_text, header_signals, generator_signal, resource_signals])
    return visible_text, combined, resp.text


def scrape_and_detect(url: str, timeout: int = 10) -> dict:
    """Scrape a URL and run its text + technical fingerprints through the
    technology detector, plus best-effort client/company contact details.

    Returns the detect_from_text result dict extended with 'url',
    'chars_scraped' (length of the visible text, for display purposes),
    and 'contact' (company_name, emails, phones, address).
    """
    visible_text, combined, html = fetch_page_signals(url, timeout=timeout)
    result = detect_from_text(combined)
    result["url"] = url
    result["chars_scraped"] = len(visible_text)
    result["contact"] = extract_contact_details(html, visible_text)
    return result
