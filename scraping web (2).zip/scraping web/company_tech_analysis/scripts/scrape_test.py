"""
Basic web scraper - single test run.

Fetches a small list of URLs and runs the scrape -> detect pipeline
(utils.scraper) to see which technologies/vendors are mentioned.
Prints results to the console; no scheduling, no database writes, no
retry logic - just enough to prove the pipeline works end to end.

Usage:
    python scrape_test.py
    python scrape_test.py https://example.com https://another-site.com
"""
import sys
import requests

sys.path.append("..")
from utils.scraper import scrape_and_detect

DEFAULT_URLS = [
    "https://example.com",
]

if __name__ == "__main__":
    urls = sys.argv[1:] if len(sys.argv) > 1 else DEFAULT_URLS

    for url in urls:
        print(f"\n{'='*70}\nScraping: {url}\n{'='*70}")
        try:
            result = scrape_and_detect(url)
        except requests.RequestException as e:
            print(f"  Failed to fetch: {e}")
            continue

        print(f"  Characters scraped : {result['chars_scraped']}")
        print(f"  Technologies found : {result['technologies'] or 'none'}")
        print(f"  Vendors found      : {result['vendors'] or 'none'}")
        print(f"  Categories found   : {result['categories'] or 'none'}")
