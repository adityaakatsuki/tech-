"""
Batch-scrape a seed list of real, public company websites and store the
detected technologies/vendors/categories in the scraped_records table
(company_tech.db), replacing reliance on the synthetic sample CSV.

Usage:
    python scrape_real_companies.py
"""
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parents[1]))
sys.path.append(str(Path(__file__).resolve().parents[2]))

import requests
from utils.scraper import scrape_and_detect
from database import init_db, SessionLocal, add_scraped_record

REAL_COMPANIES = [
    # Big Tech / SaaS / Dev tools
    "https://stripe.com", "https://github.com", "https://www.atlassian.com",
    "https://www.google.com", "https://www.microsoft.com", "https://www.apple.com",
    "https://www.meta.com", "https://x.com", "https://www.linkedin.com",
    "https://www.adobe.com", "https://www.oracle.com", "https://www.ibm.com",
    "https://www.intel.com", "https://www.nvidia.com", "https://www.amd.com",
    "https://www.cisco.com", "https://www.sap.com", "https://www.servicenow.com",
    "https://www.workday.com", "https://www.zoom.us", "https://www.docusign.com",
    "https://www.twilio.com", "https://www.hubspot.com", "https://www.zendesk.com",
    "https://asana.com", "https://www.notion.so", "https://www.figma.com",
    "https://www.canva.com", "https://monday.com", "https://www.airtable.com",
    "https://trello.com", "https://www.box.com", "https://www.okta.com",
    "https://auth0.com", "https://www.snowflake.com", "https://www.databricks.com",
    "https://www.mongodb.com", "https://www.elastic.co", "https://www.datadoghq.com",
    "https://newrelic.com", "https://www.pagerduty.com", "https://sentry.io",
    "https://circleci.com", "https://about.gitlab.com", "https://bitbucket.org",
    "https://www.digitalocean.com", "https://www.linode.com", "https://www.vultr.com",
    "https://www.heroku.com", "https://vercel.com", "https://www.netlify.com",
    "https://www.fastly.com", "https://www.akamai.com", "https://cloudinary.com",
    "https://www.salesforce.com", "https://www.dropbox.com", "https://www.cloudflare.com",
    "https://slack.com", "https://www.netflix.com", "https://www.airbnb.com",
    "https://www.spotify.com", "https://www.samsung.com", "https://www.sony.com",
    "https://www.dell.com", "https://www.hp.com", "https://www.lenovo.com",
    "https://www.vmware.com", "https://www.redhat.com",
    "https://www.autodesk.com", "https://www.intuit.com", "https://www.paloaltonetworks.com",
    "https://www.crowdstrike.com", "https://www.fortinet.com", "https://www.splunk.com",

    # Finance
    "https://www.visa.com", "https://www.mastercard.com", "https://www.paypal.com",
    "https://www.americanexpress.com", "https://www.chase.com", "https://www.bankofamerica.com",
    "https://www.wellsfargo.com", "https://www.goldmansachs.com", "https://www.morganstanley.com",
    "https://www.jpmorgan.com", "https://www.blackrock.com", "https://www.fidelity.com",
    "https://www.schwab.com", "https://robinhood.com", "https://www.coinbase.com",
    "https://www.plaid.com", "https://www.chime.com", "https://www.sofi.com",
    "https://wise.com", "https://www.revolut.com", "https://www.citigroup.com",
    "https://www.hsbc.com", "https://www.barclays.co.uk", "https://www.ubs.com",

    # Retail / E-commerce
    "https://www.walmart.com", "https://www.target.com", "https://www.costco.com",
    "https://www.homedepot.com", "https://www.lowes.com", "https://www.bestbuy.com",
    "https://www.ikea.com", "https://www.nike.com", "https://www.adidas.com",
    "https://www.zara.com", "https://www2.hm.com", "https://www.macys.com",
    "https://www.nordstrom.com", "https://www.ebay.com", "https://www.etsy.com",
    "https://www.wayfair.com", "https://www.chewy.com", "https://www.instacart.com",
    "https://www.doordash.com", "https://www.lyft.com", "https://www.uber.com",
    "https://www.grubhub.com", "https://www.shopify.com", "https://www.zappos.com",

    # Media / Entertainment
    "https://www.disney.com", "https://www.warnerbros.com", "https://www.nbcuniversal.com",
    "https://www.hulu.com", "https://www.paramount.com", "https://www.sonypictures.com",
    "https://soundcloud.com", "https://www.twitch.tv", "https://www.youtube.com",
    "https://www.pinterest.com", "https://www.reddit.com", "https://www.snap.com",
    "https://discord.com", "https://www.tumblr.com", "https://vimeo.com",

    # Travel / Airlines / Hospitality
    "https://www.united.com", "https://www.delta.com", "https://www.aa.com",
    "https://www.southwest.com", "https://www.jetblue.com", "https://www.ryanair.com",
    "https://www.easyjet.com", "https://www.expedia.com", "https://www.booking.com",
    "https://www.tripadvisor.com", "https://www.marriott.com", "https://www.hilton.com",
    "https://www.hyatt.com",

    # Automotive
    "https://www.tesla.com", "https://www.ford.com", "https://www.gm.com",
    "https://www.toyota.com", "https://www.honda.com", "https://www.bmw.com",
    "https://www.mercedes-benz.com", "https://www.vw.com", "https://www.hyundai.com",
    "https://www.rivian.com",

    # Healthcare / Pharma
    "https://www.pfizer.com", "https://www.modernatx.com", "https://www.jnj.com",
    "https://www.unitedhealthgroup.com", "https://www.cvshealth.com", "https://www.cigna.com",
    "https://www.gsk.com", "https://www.novartis.com", "https://www.roche.com",

    # Telecom
    "https://www.verizon.com", "https://www.att.com", "https://www.t-mobile.com",
    "https://www.xfinity.com", "https://www.vodafone.com", "https://www.orange.com",

    # Energy
    "https://corporate.exxonmobil.com", "https://www.chevron.com", "https://www.shell.com",
    "https://www.bp.com", "https://totalenergies.com",

    # Consulting / Enterprise services
    "https://www.accenture.com", "https://www2.deloitte.com", "https://www.mckinsey.com",
    "https://www.bcg.com", "https://www.pwc.com", "https://kpmg.com", "https://www.ey.com",

    # Food / Beverage
    "https://www.coca-colacompany.com", "https://www.pepsico.com", "https://www.nestle.com",
    "https://www.starbucks.com", "https://www.mcdonalds.com", "https://www.chipotle.com",
    "https://www.dominos.com", "https://www.yum.com",

    # Misc well-known real companies
    "https://www.ge.com", "https://www.honeywell.com", "https://www.3m.com",
    "https://www.boeing.com", "https://www.lockheedmartin.com", "https://www.siemens.com",
    "https://www.philips.com", "https://www.lg.com", "https://www.panasonic.com",
    "https://www.epicgames.com", "https://www.ea.com", "https://www.activision.com",
    "https://www.ubisoft.com", "https://www.nintendo.com", "https://www.playstation.com",
    "https://www.xbox.com", "https://www.roblox.com", "https://www.unity.com",
    "https://www.wix.com", "https://www.squarespace.com", "https://www.godaddy.com",
    "https://www.bluehost.com", "https://www.mailchimp.com", "https://www.constantcontact.com",
    "https://www.surveymonkey.com", "https://www.typeform.com", "https://www.calendly.com",
    "https://www.zapier.com", "https://www.ifttt.com", "https://www.segment.com",
    "https://www.amplitude.com", "https://mixpanel.com", "https://www.braze.com",
]

if __name__ == "__main__":
    init_db()
    db = SessionLocal()
    ok, failed = 0, 0
    try:
        for i, url in enumerate(REAL_COMPANIES, 1):
            print(f"\n[{i}/{len(REAL_COMPANIES)}] Scraping: {url}")
            try:
                result = scrape_and_detect(url, timeout=8)
            except requests.RequestException as e:
                print(f"  Failed: {e}")
                failed += 1
                continue

            add_scraped_record(
                db,
                url=url,
                technologies=result["technologies"],
                vendors=result["vendors"],
                categories=result["categories"],
                chars_scraped=result["chars_scraped"]
            )
            ok += 1
            print(f"  Technologies: {result['technologies'] or 'none'}")
    finally:
        db.close()

    print(f"\n{'='*70}\nDone: {ok} stored, {failed} failed, {len(REAL_COMPANIES)} total\n{'='*70}")
