"""
Generate realistic sample dataset for Company Technology Usage Analysis
Creates 200 records with realistic company technology data
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# Set random seed for reproducibility
np.random.seed(42)

# Define data pools
technologies = [
    # Programming Languages
    "Python", "JavaScript", "TypeScript", "Java", "C#", "Go", "Rust", "Kotlin", "PHP", "Ruby",
    "C++", "Swift", "Objective-C", "R", "Scala", "Haskell",
    # Frontend Frameworks
    "React", "Vue.js", "Angular", "Svelte", "Next.js", "Nuxt.js", "Remix", "Astro", "Gatsby", "Ember.js",
    # Backend Frameworks
    "Node.js", "Django", "FastAPI", "Spring Boot", "Express.js", "Flask", "ASP.NET Core", "Laravel", "Gin", "Fiber",
    # Cloud Platforms
    "AWS", "Google Cloud", "Azure", "DigitalOcean", "Heroku", "Vercel", "Netlify", "Linode", "OVH",
    # Databases
    "PostgreSQL", "MySQL", "MongoDB", "Redis", "DynamoDB", "Elasticsearch", "Cassandra", "Oracle", 
    "SQLite", "MariaDB", "CouchDB", "Neo4j", "InfluxDB",
    # DevOps/Infrastructure
    "Docker", "Kubernetes", "Terraform", "Jenkins", "GitLab CI", "GitHub Actions", "CircleCI", "ArgoCD",
    "Ansible", "Chef", "Puppet", "Vagrant", "AWS CloudFormation",
    # Data & Analytics
    "TensorFlow", "PyTorch", "Apache Spark", "Hadoop", "Apache Kafka", "Apache Airflow", "Snowflake", "Tableau",
    "Power BI", "Looker", "Dbt", "Apache Hive", "Presto",
    # Testing & Quality
    "Jest", "Pytest", "Selenium", "JUnit", "Cypress", "Mocha", "Vitest", "Postman", "SoapUI", "TestNG",
    "Cucumber", "Playwright", "Appium",
    # Message Queues
    "RabbitMQ", "Apache MQ", "AWS SQS", "Apache Pulsar", "NATS", "Apache Camel", "AWS SNS",
    # Monitoring & Logging
    "Prometheus", "Grafana", "Datadog", "New Relic", "ELK Stack", "CloudWatch", "Splunk", "Sumo Logic",
    "Sentry", "Jaeger", "Zipkin",
    # API & Integration
    "GraphQL", "REST API", "gRPC", "SOAP", "OpenAPI", "Swagger", "Kong", "Tyk", "AWS API Gateway",
    # Version Control & CI/CD
    "Git", "GitHub", "GitLab", "Bitbucket", "Gitea",
    # Containers & Orchestration
    "Docker Compose", "OpenShift", "Nomad", "Amazon ECS", "AWS EKS",
    # Web Servers
    "Nginx", "Apache", "Caddy", "Tomcat", "IIS",
    # Mobile Development
    "React Native", "Flutter", "Xamarin", "Ionic", "NativeScript",
    # Other Tools
    "Linux", "Windows Server", "macOS", "Redis Cluster", "Vault", "Consul", "Microservices", "Serverless",
    "GraphQL Apollo", "Prisma", "TypeORM", "Sequelize", "SQLAlchemy"
]

departments = [
    "Engineering", "Frontend Development", "Backend Development", "Data Science",
    "DevOps/Infrastructure", "Database Administration", "QA/Testing", "Security",
    "Cloud Architecture", "ML Engineering", "API Development", "Mobile Development",
    "Platform Engineering", "Site Reliability", "Solution Architecture", "Tech Leadership",
    "System Administration", "Performance Engineering", "Research", "Product Engineering"
]

projects = []
for i in range(50):
    projects.append(f"Project {chr(65 + i % 26)}")
    projects.append(f"Internal Tool-{i // 26 + 1}")
    projects.append(f"Client App-{i // 26 + 1}")
projects = list(set(projects))[:50]

statuses = ["Active", "Planned", "Deprecated", "Legacy", "In Evaluation", "Experimental"]
license_types = ["Open Source", "Commercial", "Community", "Enterprise", "Freemium", "Proprietary", "GPL", "MIT"]

# Create dataset
records = []

for i in range(200):
    status = np.random.choice(
        statuses, 
        p=[0.45, 0.20, 0.15, 0.10, 0.07, 0.03]
    )
    
    # Determine adoption rate based on status
    if status == "Active":
        adoption = np.random.randint(60, 100)
    elif status == "Planned":
        adoption = np.random.randint(10, 40)
    elif status == "Deprecated":
        adoption = np.random.randint(5, 35)
    elif status == "Legacy":
        adoption = np.random.randint(1, 20)
    elif status == "In Evaluation":
        adoption = np.random.randint(15, 50)
    else:  # Experimental
        adoption = np.random.randint(5, 30)
    
    record = {
        "technologies": np.random.choice(technologies),
        "department": np.random.choice(departments),
        "project_name": np.random.choice(projects),
        "adoption_rate": adoption,
        "status": status,
        "team_size": np.random.randint(1, 35),
        "cost_monthly": np.random.choice(
            np.concatenate([
                np.random.randint(0, 100, 50),  # Free options
                np.random.randint(100, 5000, 100),  # Mid-tier
                np.random.randint(5000, 50000, 50)  # Enterprise
            ])
        ),
        "license_type": np.random.choice(license_types),
        "years_in_use": np.random.randint(0, 10),
        "last_reviewed": (datetime.now() - timedelta(days=np.random.randint(0, 365))).strftime("%Y-%m-%d"),
        "priority": np.random.choice(["Critical", "High", "Medium", "Low"], p=[0.15, 0.25, 0.35, 0.25]),
        "migration_target": np.random.choice([None, np.random.choice(technologies)], p=[0.85, 0.15])
    }
    records.append(record)

# Add popular technology combinations for realism
popular_combos = [
    ("React", "Frontend Development", 85), ("Python", "Data Science", 88), ("AWS", "DevOps/Infrastructure", 92),
    ("PostgreSQL", "Backend Development", 87), ("Docker", "Platform Engineering", 90), ("Kubernetes", "DevOps/Infrastructure", 78),
    ("TypeScript", "Frontend Development", 83), ("Node.js", "Backend Development", 85), ("TensorFlow", "ML Engineering", 82),
    ("Terraform", "Cloud Architecture", 88), ("Go", "Backend Development", 75), ("Vue.js", "Frontend Development", 72),
    ("MongoDB", "Backend Development", 68), ("Redis", "Backend Development", 85), ("Prometheus", "Site Reliability", 80),
    ("Nginx", "DevOps/Infrastructure", 94), ("GitHub", "Engineering", 96), ("Linux", "System Administration", 98),
]

for tech, dept, adoption in popular_combos:
    record = {
        "technologies": tech,
        "department": dept,
        "project_name": np.random.choice(projects),
        "adoption_rate": adoption + np.random.randint(-5, 10),
        "status": np.random.choice(["Active", "Planned", "Active"], p=[0.5, 0.2, 0.3]),
        "team_size": np.random.randint(3, 25),
        "cost_monthly": np.random.randint(500, 20000),
        "license_type": np.random.choice(license_types),
        "years_in_use": np.random.randint(2, 8),
        "last_reviewed": (datetime.now() - timedelta(days=np.random.randint(0, 90))).strftime("%Y-%m-%d"),
        "priority": "High",
        "migration_target": None
    }
    records.append(record)

# Create DataFrame
df = pd.DataFrame(records)

# Remove exact duplicates
df = df.drop_duplicates(
    subset=["technologies", "department", "project_name"], 
    keep="first"
)

# Ensure we have close to 200 records
if len(df) > 200:
    df = df.sample(n=200, random_state=42).reset_index(drop=True)
else:
    # Keep as is if less than 200
    df = df.reset_index(drop=True)

# Reorder columns
column_order = [
    "technologies", "department", "project_name", "adoption_rate", 
    "status", "team_size", "cost_monthly", "license_type", 
    "years_in_use", "last_reviewed", "priority", "migration_target"
]
df = df[column_order]

# Save to CSV
output_path = r"E:\scraping web\company_tech_analysis\data\technologies.csv"
df.to_csv(output_path, index=False)

print("✅ Dataset created successfully!")
print(f"📊 Total records: {len(df)}")
print(f"📍 File saved to: {output_path}\n")

print("=" * 70)
print("📈 DATASET SUMMARY")
print("=" * 70)
print(f"✓ Unique Technologies: {df['technologies'].nunique()}")
print(f"✓ Unique Departments: {df['department'].nunique()}")
print(f"✓ Unique Projects: {df['project_name'].nunique()}")
print(f"✓ Average Adoption Rate: {df['adoption_rate'].mean():.1f}%")
print(f"✓ Average Team Size: {df['team_size'].mean():.1f}")
print(f"✓ Average Monthly Cost: ${df['cost_monthly'].mean():,.0f}")

print("\n" + "=" * 70)
print("📊 STATUS DISTRIBUTION")
print("=" * 70)
status_counts = df['status'].value_counts()
for status, count in status_counts.items():
    percentage = (count / len(df)) * 100
    print(f"  {status:<20} : {count:>3} records ({percentage:>5.1f}%)")

print("\n" + "=" * 70)
print("💰 LICENSE TYPE DISTRIBUTION")
print("=" * 70)
license_counts = df['license_type'].value_counts()
for license_type, count in license_counts.items():
    percentage = (count / len(df)) * 100
    print(f"  {license_type:<20} : {count:>3} records ({percentage:>5.1f}%)")

print("\n" + "=" * 70)
print("🏢 TOP 10 DEPARTMENTS")
print("=" * 70)
dept_counts = df['department'].value_counts().head(10)
for dept, count in dept_counts.items():
    percentage = (count / len(df)) * 100
    print(f"  {dept:<30} : {count:>3} records ({percentage:>5.1f}%)")

print("\n" + "=" * 70)
print("🛠️  TOP 15 TECHNOLOGIES")
print("=" * 70)
tech_counts = df['technologies'].value_counts().head(15)
for tech, count in tech_counts.items():
    avg_adoption = df[df['technologies'] == tech]['adoption_rate'].mean()
    print(f"  {tech:<30} : {count:>3} records (Avg Adoption: {avg_adoption:>5.1f}%)")

print("\n" + "=" * 70)
print("📋 SAMPLE RECORDS (First 15)")
print("=" * 70)
print(df.head(15).to_string(index=False))

print("\n" + "=" * 70)
print("📊 STATISTICS")
print("=" * 70)
stats_df = df[['adoption_rate', 'team_size', 'cost_monthly', 'years_in_use']].describe()
print(stats_df.to_string())

print("\n✅ CSV file ready for use with Streamlit application!")
