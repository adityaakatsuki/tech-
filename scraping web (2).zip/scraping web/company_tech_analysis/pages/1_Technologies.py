"""
Page: Technologies Overview
Multi-page app component for browsing and analyzing individual technologies
"""

import streamlit as st
import pandas as pd
import plotly.express as px
from utils.data_loader import load_technology_data
from utils.data_processor import filter_active_technologies
from utils.tech_detector import detect_from_text

st.set_page_config(page_title="Technologies", page_icon="🛠️")

st.title("🛠️ Technology Catalog")
st.markdown("Browse, analyze, and compare technologies used across your organization.")

# Technology detection UI
st.divider()
st.header("🔎 Technology Detector")
st.markdown("Paste free-form text (job postings, README, docs) and detect mentioned technologies, vendors, and categories.")
input_text = st.text_area("Text to scan", height=150)
if st.button("Detect"):
    if input_text and input_text.strip():
        result = detect_from_text(input_text)
        st.subheader("Detected Technologies")
        st.write(result.get('technologies') or [])
        st.subheader("Detected Vendors")
        st.write(result.get('vendors') or [])
        st.subheader("Detected Categories")
        st.write(result.get('categories') or [])
        if result.get('matches'):
            st.subheader("Matches (term, kind, span)")
            # Normalize matches for display
            matches_df = pd.DataFrame([{
                'term': m.get('term'),
                'kind': m.get('kind'),
                'start': m.get('span')[0] if m.get('span') else None,
                'end': m.get('span')[1] if m.get('span') else None,
                'category': m.get('category') if m.get('category') else ''
            } for m in result.get('matches')])
            st.table(matches_df)
    else:
        st.info("Enter text to analyze and click Detect.")

st.divider()

data = load_technology_data()
if not data.empty:
    data = filter_active_technologies(data)
    
    # Search and filter
    col1, col2, col3 = st.columns(3)
    
    with col1:
        search_term = st.text_input("Search technologies", "")
    with col2:
        min_adoption = st.slider("Min adoption rate", 0, 100, 0)
    with col3:
        status_filter = st.selectbox("Status", ["All", "Active", "Deprecated"])
    
    # Apply filters
    filtered_data = data.copy()
    if search_term:
        filtered_data = filtered_data[filtered_data['technologies'].str.contains(search_term, case=False)]
    if min_adoption > 0:
        filtered_data = filtered_data[filtered_data['adoption_rate'] >= min_adoption]
    
    # Display results
    st.subheader("Technology List")
    st.dataframe(filtered_data, use_container_width=True)
    
    # Visualization
    if not filtered_data.empty:
        fig = px.bar(
            filtered_data.groupby('technologies')['adoption_rate'].mean().reset_index(),
            x='technologies',
            y='adoption_rate',
            title="Average Adoption Rate by Technology"
        )
        st.plotly_chart(fig, use_container_width=True)
else:
    st.warning("No data available. Please load technology data.")
