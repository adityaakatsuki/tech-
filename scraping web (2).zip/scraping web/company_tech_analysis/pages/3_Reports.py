"""
Page: Reports & Exports
Multi-page app component for generating reports and exporting data
"""

import streamlit as st
import pandas as pd
from datetime import datetime
from utils.data_loader import load_technology_data
from utils.data_processor import get_technology_summary

st.set_page_config(page_title="Reports", page_icon="📋")

st.title("📋 Reports & Exports")
st.markdown("Generate comprehensive reports and export data for further analysis.")

data = load_technology_data()

# Report type selection
report_type = st.selectbox(
    "Select Report Type",
    ["Executive Summary", "Detailed Analysis", "Technology Inventory", "Export Data"]
)

if report_type == "Executive Summary":
    st.subheader("Executive Summary Report")
    
    if not data.empty:
        summary = get_technology_summary(data)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.info(f"""
            **Report Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
            
            **Key Metrics:**
            - Total Technologies: {summary['total_technologies']}
            - Average Adoption Rate: {summary['avg_adoption_rate']:.1f}%
            - Highest Adoption: {summary['max_adoption']:.1f}%
            - Lowest Adoption: {summary['min_adoption']:.1f}%
            - Total Projects: {summary['total_projects']}
            """)
        
        with col2:
            st.info("""
            **Insights:**
            - Monitor technologies with low adoption rates
            - Plan migration strategies for deprecated tech
            - Prioritize team training for new technologies
            - Consolidate redundant technology stacks
            """)

elif report_type == "Detailed Analysis":
    st.subheader("Detailed Analysis Report")
    
    if not data.empty:
        analysis_tabs = st.tabs(["By Department", "By Status", "By Adoption Rate"])
        
        with analysis_tabs[0]:
            st.write("**Technology Distribution by Department**")
            dept_dist = data.groupby('department')['technologies'].nunique()
            st.bar_chart(dept_dist)
        
        with analysis_tabs[1]:
            st.write("**Technology Status Distribution**")
            status_dist = data['status'].value_counts()
            st.pie_chart(status_dist)
        
        with analysis_tabs[2]:
            st.write("**Adoption Rate Analysis**")
            adoption_stats = data.groupby('status')['adoption_rate'].agg(['mean', 'min', 'max'])
            st.dataframe(adoption_stats)

elif report_type == "Technology Inventory":
    st.subheader("Complete Technology Inventory")
    
    if not data.empty:
        # Filters
        col1, col2 = st.columns(2)
        
        with col1:
            status_filter = st.multiselect("Filter by Status", data['status'].unique(), default=data['status'].unique())
        
        with col2:
            dept_filter = st.multiselect("Filter by Department", data['department'].unique(), default=data['department'].unique())
        
        # Apply filters
        filtered = data[(data['status'].isin(status_filter)) & (data['department'].isin(dept_filter))]
        
        st.dataframe(filtered.sort_values('adoption_rate', ascending=False), use_container_width=True)

elif report_type == "Export Data":
    st.subheader("Export Data")
    
    if not data.empty:
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button("📥 Download as CSV"):
                csv = data.to_csv(index=False)
                st.download_button(
                    label="Click to download CSV",
                    data=csv,
                    file_name=f"technology_data_{datetime.now().strftime('%Y%m%d')}.csv",
                    mime="text/csv"
                )
        
        with col2:
            if st.button("📥 Download as Excel"):
                st.info("Excel export requires openpyxl library. Install via requirements.txt")
        
        with col3:
            if st.button("📥 Download as JSON"):
                json_data = data.to_json(orient='records')
                st.download_button(
                    label="Click to download JSON",
                    data=json_data,
                    file_name=f"technology_data_{datetime.now().strftime('%Y%m%d')}.json",
                    mime="application/json"
                )
