"""
Page: Department Analytics
Multi-page app component for analyzing technology usage by department
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from utils.data_loader import load_technology_data
from utils.data_processor import aggregate_by_department

st.set_page_config(page_title="Departments", page_icon="🏢")

st.title("🏢 Department Analytics")
st.markdown("Analyze technology adoption and usage patterns by department.")

data = load_technology_data()

if not data.empty:
    # Department selection
    selected_dept = st.selectbox(
        "Select Department",
        data['department'].unique()
    )
    
    dept_data = data[data['department'] == selected_dept]
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Technologies Used", dept_data['technologies'].nunique())
    with col2:
        st.metric("Avg Adoption Rate", f"{dept_data['adoption_rate'].mean():.1f}%")
    with col3:
        st.metric("Active Projects", len(dept_data[dept_data['status'] == 'Active']))
    
    st.divider()
    
    # Department technology details
    st.subheader(f"Technologies in {selected_dept}")
    st.dataframe(dept_data[['technologies', 'project_name', 'adoption_rate', 'status']], use_container_width=True)
    
    # Cross-department comparison
    st.subheader("Cross-Department Comparison")
    dept_summary = aggregate_by_department(data)
    
    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=dept_summary['department'],
        y=dept_summary['adoption_rate'],
        name='Avg Adoption Rate',
        marker_color='lightblue'
    ))
    
    st.plotly_chart(fig, use_container_width=True)
else:
    st.warning("No data available. Please load technology data.")
